/*

roman numeral to interger

Given a roman numeral, convert it to an integer.

*/

#include <vector>
#include <iostream>
#include "common.h"

using namespace std;

int main(int argc, char* argv[]) {
	return 0;
}