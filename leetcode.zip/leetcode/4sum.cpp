/*
 
 4 sum

*/

 #include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include "common.h"

using namespace std;




int main(int argc, char* argv[]) {
	return 0;
}